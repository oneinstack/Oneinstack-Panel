import{bo as o}from"./index-BezOvEEQ.js";const s=s=>["",...o].includes(s);export{s as i};
