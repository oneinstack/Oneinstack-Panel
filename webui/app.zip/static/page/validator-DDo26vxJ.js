import{bq as s}from"./index-BCwSlzuk.js";const i=i=>["",...s].includes(i);export{i};
