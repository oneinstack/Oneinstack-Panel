import{bA as s}from"./index-Cb0V7W1X.js";const i=i=>["",...s].includes(i);export{i};
