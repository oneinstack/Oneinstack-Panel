import{by as r}from"./index-Cb0V7W1X.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
