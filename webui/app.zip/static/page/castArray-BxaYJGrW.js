import{ba as r}from"./index-f7zviUUJ.js";function n(){if(!arguments.length)return[];var n=arguments[0];return r(n)?n:[n]}export{n as c};
