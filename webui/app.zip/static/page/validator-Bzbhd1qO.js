import{bo as o}from"./index-CFjQbRna.js";const s=s=>["",...o].includes(s);export{s as i};
