import{aj as e}from"./index-C7agYfF7.js";const a=a=>e?window.requestAnimationFrame(a):setTimeout(a,16),i=a=>e?window.cancelAnimationFrame(a):clearTimeout(a);export{i as c,a as r};
