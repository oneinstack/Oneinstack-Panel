import{bd as s}from"./index-f7zviUUJ.js";const i=i=>["",...s].includes(i);export{i};
