import{bo as o}from"./index-Wdlop7dQ.js";const s=s=>["",...o].includes(s);export{s as i};
