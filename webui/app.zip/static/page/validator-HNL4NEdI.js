import{bq as s}from"./index-C7agYfF7.js";const i=i=>["",...s].includes(i);export{i};
