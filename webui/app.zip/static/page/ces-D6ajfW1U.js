import{_ as e}from"./_plugin-vue_export-helper-BCo6x5W8.js";import{b as r,o}from"./index-Cb0V7W1X.js";const t=e({},[["render",function(e,t){return o(),r("div")}]]);export{t as default};
